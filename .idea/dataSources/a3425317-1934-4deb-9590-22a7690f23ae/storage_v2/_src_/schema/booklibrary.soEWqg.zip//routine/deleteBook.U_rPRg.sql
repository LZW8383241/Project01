create
    definer = root@localhost procedure deleteBook(IN id int)
BEGIN
	#Routine body goes here...
	delete from book where book.id = id;
END;

